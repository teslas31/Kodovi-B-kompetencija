﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B13B14
{
    public partial class Pocetna : Form
    {
        public Pocetna()
        {
            InitializeComponent();
        }

        private void knjigeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Unos_knjiga f = new Unos_knjiga();f.Show();
        }

        private void autoriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Unos_autora f = new Unos_autora();f.Show();
        }

        private void poKategorijamaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Po_kategorijama f = new Po_kategorijama();f.Show();
        }

        private void poAutorimaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Po_autorima f = new Po_autorima();f.Show();
        }

        private void izlazToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿namespace B10
{
    partial class Periodi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PeriodID = new System.Windows.Forms.TextBox();
            this.Period = new System.Windows.Forms.TextBox();
            this.Unesi = new System.Windows.Forms.Button();
            this.Obrisi = new System.Windows.Forms.Button();
            this.Izmeni = new System.Windows.Forms.Button();
            this.Izlaz = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sifra";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Naziv";
            // 
            // PeriodID
            // 
            this.PeriodID.Location = new System.Drawing.Point(70, 31);
            this.PeriodID.Name = "PeriodID";
            this.PeriodID.Size = new System.Drawing.Size(69, 20);
            this.PeriodID.TabIndex = 2;
            // 
            // Period
            // 
            this.Period.Location = new System.Drawing.Point(70, 64);
            this.Period.Name = "Period";
            this.Period.Size = new System.Drawing.Size(127, 20);
            this.Period.TabIndex = 3;
            // 
            // Unesi
            // 
            this.Unesi.Location = new System.Drawing.Point(15, 123);
            this.Unesi.Name = "Unesi";
            this.Unesi.Size = new System.Drawing.Size(75, 23);
            this.Unesi.TabIndex = 4;
            this.Unesi.Text = "Unesi";
            this.Unesi.UseVisualStyleBackColor = true;
            this.Unesi.Click += new System.EventHandler(this.Unesi_Click);
            // 
            // Obrisi
            // 
            this.Obrisi.Location = new System.Drawing.Point(113, 123);
            this.Obrisi.Name = "Obrisi";
            this.Obrisi.Size = new System.Drawing.Size(75, 23);
            this.Obrisi.TabIndex = 5;
            this.Obrisi.Text = "Obrisi";
            this.Obrisi.UseVisualStyleBackColor = true;
            this.Obrisi.Click += new System.EventHandler(this.Obrisi_Click);
            // 
            // Izmeni
            // 
            this.Izmeni.Location = new System.Drawing.Point(208, 123);
            this.Izmeni.Name = "Izmeni";
            this.Izmeni.Size = new System.Drawing.Size(75, 23);
            this.Izmeni.TabIndex = 6;
            this.Izmeni.Text = "Izmeni";
            this.Izmeni.UseVisualStyleBackColor = true;
            this.Izmeni.Click += new System.EventHandler(this.Izmeni_Click);
            // 
            // Izlaz
            // 
            this.Izlaz.Location = new System.Drawing.Point(113, 165);
            this.Izlaz.Name = "Izlaz";
            this.Izlaz.Size = new System.Drawing.Size(75, 23);
            this.Izlaz.TabIndex = 7;
            this.Izlaz.Text = "Izlaz";
            this.Izlaz.UseVisualStyleBackColor = true;
            this.Izlaz.Click += new System.EventHandler(this.Izlaz_Click);
            // 
            // Periodi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(305, 218);
            this.Controls.Add(this.Izlaz);
            this.Controls.Add(this.Izmeni);
            this.Controls.Add(this.Obrisi);
            this.Controls.Add(this.Unesi);
            this.Controls.Add(this.Period);
            this.Controls.Add(this.PeriodID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Periodi";
            this.Text = "Periodi";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox PeriodID;
        private System.Windows.Forms.TextBox Period;
        private System.Windows.Forms.Button Unesi;
        private System.Windows.Forms.Button Obrisi;
        private System.Windows.Forms.Button Izmeni;
        private System.Windows.Forms.Button Izlaz;
    }
}
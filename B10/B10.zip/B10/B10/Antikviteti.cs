﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B10
{
    public partial class Antikviteti : Form
    {
        public Antikviteti()
        {
            InitializeComponent();
        }

        private void periodiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Periodi p = new Periodi();
            p.Show();
        }

        private void poTipuAntikvitetaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Po_antikvitetu a = new Po_antikvitetu();
            a.Show();
        }

        private void krajToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

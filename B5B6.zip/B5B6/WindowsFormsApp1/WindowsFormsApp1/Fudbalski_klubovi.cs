﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Fudbalski_klubovi : Form
    {
        public Fudbalski_klubovi()
        {
            InitializeComponent();
        }

        private void unosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnosGradova f = new UnosGradova();
            f.Show();
        }

        private void spisakIgracaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Spisak_Igraca f = new Spisak_Igraca();
            f.Show();
        }

        private void unosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            UnosStadiona f = new UnosStadiona();
            f.Show();
        }

        private void kapacitetStadionaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KapacitetStadiona f = new KapacitetStadiona();
            f.Show();
        }

        private void krajRadaAltKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

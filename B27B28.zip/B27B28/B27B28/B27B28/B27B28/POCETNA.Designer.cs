﻿namespace B27B28
{
    partial class POCETNA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.uNOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rODITELJIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dECAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sPISKOVIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bROJDECEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uZRASTDECEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kRAJToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iZLAZToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uNOSToolStripMenuItem,
            this.sPISKOVIToolStripMenuItem,
            this.kRAJToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(412, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // uNOSToolStripMenuItem
            // 
            this.uNOSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rODITELJIToolStripMenuItem,
            this.dECAToolStripMenuItem});
            this.uNOSToolStripMenuItem.Name = "uNOSToolStripMenuItem";
            this.uNOSToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.uNOSToolStripMenuItem.Text = "UNOS";
            // 
            // rODITELJIToolStripMenuItem
            // 
            this.rODITELJIToolStripMenuItem.Name = "rODITELJIToolStripMenuItem";
            this.rODITELJIToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.rODITELJIToolStripMenuItem.Text = "RODITELJI";
            this.rODITELJIToolStripMenuItem.Click += new System.EventHandler(this.rODITELJIToolStripMenuItem_Click);
            // 
            // dECAToolStripMenuItem
            // 
            this.dECAToolStripMenuItem.Name = "dECAToolStripMenuItem";
            this.dECAToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.dECAToolStripMenuItem.Text = "DECA";
            this.dECAToolStripMenuItem.Click += new System.EventHandler(this.dECAToolStripMenuItem_Click);
            // 
            // sPISKOVIToolStripMenuItem
            // 
            this.sPISKOVIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bROJDECEToolStripMenuItem,
            this.uZRASTDECEToolStripMenuItem});
            this.sPISKOVIToolStripMenuItem.Name = "sPISKOVIToolStripMenuItem";
            this.sPISKOVIToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.sPISKOVIToolStripMenuItem.Text = "SPISKOVI";
            // 
            // bROJDECEToolStripMenuItem
            // 
            this.bROJDECEToolStripMenuItem.Name = "bROJDECEToolStripMenuItem";
            this.bROJDECEToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.bROJDECEToolStripMenuItem.Text = "BROJ DECE";
            this.bROJDECEToolStripMenuItem.Click += new System.EventHandler(this.bROJDECEToolStripMenuItem_Click);
            // 
            // uZRASTDECEToolStripMenuItem
            // 
            this.uZRASTDECEToolStripMenuItem.Name = "uZRASTDECEToolStripMenuItem";
            this.uZRASTDECEToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.uZRASTDECEToolStripMenuItem.Text = "UZRAST DECE";
            this.uZRASTDECEToolStripMenuItem.Click += new System.EventHandler(this.uZRASTDECEToolStripMenuItem_Click);
            // 
            // kRAJToolStripMenuItem
            // 
            this.kRAJToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iZLAZToolStripMenuItem});
            this.kRAJToolStripMenuItem.Name = "kRAJToolStripMenuItem";
            this.kRAJToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.kRAJToolStripMenuItem.Text = "KRAJ";
            // 
            // iZLAZToolStripMenuItem
            // 
            this.iZLAZToolStripMenuItem.Name = "iZLAZToolStripMenuItem";
            this.iZLAZToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.iZLAZToolStripMenuItem.Text = "IZLAZ";
            // 
            // POCETNA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "POCETNA";
            this.Text = "DNEVNI BORAVAK DECE";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem uNOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rODITELJIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dECAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sPISKOVIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bROJDECEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uZRASTDECEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kRAJToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iZLAZToolStripMenuItem;
    }
}


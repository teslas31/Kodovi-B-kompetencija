﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B27B28
{
    public partial class POCETNA : Form
    {
        public POCETNA()
        {
            InitializeComponent();
        }

        private void rODITELJIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Roditelji f = new Roditelji();
            f.Show();
        }

        private void dECAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Deca f = new Deca();
            f.Show();
        }

        private void bROJDECEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BrojDece f = new BrojDece();
            f.Show();
        }

        private void uZRASTDECEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UzrastDece f = new UzrastDece();
            f.Show();
        }
    }
}

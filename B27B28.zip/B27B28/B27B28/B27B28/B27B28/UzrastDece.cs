﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace B27B28
{
    public partial class UzrastDece : Form
    {
        public UzrastDece()
        {
            InitializeComponent();
        }
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source=B27B28.accdb");
        private void UzrastDece_Load(object sender, EventArgs e)
        {
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //listView1.Items.Clear();

            string upit = "Select Ime, Prezime, DatumRodjenja AS [Datum Rodjenja], Pol From Dete, Pol Where Dete.PolID=Pol.PolID";

            if (checkBox1.Checked && checkBox2.Checked)
            {
                upit += " And (Pol.Pol='Muški' Or Pol.Pol='Ženski')";
            }
            else if (checkBox1.Checked && checkBox2.Checked == false)
                upit += " And Pol.Pol='Muški'";
            else if (checkBox2.Checked && checkBox1.Checked == false)
                upit += " And Pol.Pol='Ženski'";

            DateTime danas = DateTime.Now;
            decimal godina = danas.Year - numericUpDown1.Value;
            upit += " And DatumRodjenja Like '%" + godina.ToString() + "'";

            OleDbDataAdapter da = new OleDbDataAdapter(upit, con);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(dt);
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            /*foreach (DataRow row in dt.Rows)
            {
                ListViewItem item = new ListViewItem(row[0].ToString());
                for (int i = 1; i < dt.Columns.Count; i++)
                {
                    item.SubItems.Add(row[i].ToString());
                }
                listView1.Items.Add(item);
            }*/
        }
    }
}

﻿namespace B9
{
    partial class TipAntikviteta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TipAntikvitetaID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Tip = new System.Windows.Forms.TextBox();
            this.Unesi = new System.Windows.Forms.Button();
            this.Obrisi = new System.Windows.Forms.Button();
            this.Izmeni = new System.Windows.Forms.Button();
            this.Izadji = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sifra";
            // 
            // TipAntikvitetaID
            // 
            this.TipAntikvitetaID.Location = new System.Drawing.Point(110, 83);
            this.TipAntikvitetaID.Name = "TipAntikvitetaID";
            this.TipAntikvitetaID.Size = new System.Drawing.Size(100, 20);
            this.TipAntikvitetaID.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(69, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Naziv";
            // 
            // Tip
            // 
            this.Tip.Location = new System.Drawing.Point(110, 104);
            this.Tip.Name = "Tip";
            this.Tip.Size = new System.Drawing.Size(100, 20);
            this.Tip.TabIndex = 3;
            // 
            // Unesi
            // 
            this.Unesi.Location = new System.Drawing.Point(13, 152);
            this.Unesi.Name = "Unesi";
            this.Unesi.Size = new System.Drawing.Size(75, 23);
            this.Unesi.TabIndex = 4;
            this.Unesi.Text = "Unesi";
            this.Unesi.UseVisualStyleBackColor = true;
            this.Unesi.Click += new System.EventHandler(this.Unesi_Click);
            // 
            // Obrisi
            // 
            this.Obrisi.Location = new System.Drawing.Point(110, 151);
            this.Obrisi.Name = "Obrisi";
            this.Obrisi.Size = new System.Drawing.Size(75, 23);
            this.Obrisi.TabIndex = 5;
            this.Obrisi.Text = "Obrisi";
            this.Obrisi.UseVisualStyleBackColor = true;
            this.Obrisi.Click += new System.EventHandler(this.Obrisi_Click);
            // 
            // Izmeni
            // 
            this.Izmeni.Location = new System.Drawing.Point(200, 151);
            this.Izmeni.Name = "Izmeni";
            this.Izmeni.Size = new System.Drawing.Size(75, 23);
            this.Izmeni.TabIndex = 6;
            this.Izmeni.Text = "Izmeni";
            this.Izmeni.UseVisualStyleBackColor = true;
            this.Izmeni.Click += new System.EventHandler(this.Izmeni_Click);
            // 
            // Izadji
            // 
            this.Izadji.Location = new System.Drawing.Point(110, 199);
            this.Izadji.Name = "Izadji";
            this.Izadji.Size = new System.Drawing.Size(75, 23);
            this.Izadji.TabIndex = 7;
            this.Izadji.Text = "Izadji";
            this.Izadji.UseVisualStyleBackColor = true;
            // 
            // TipAntikviteta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 291);
            this.Controls.Add(this.Izadji);
            this.Controls.Add(this.Izmeni);
            this.Controls.Add(this.Obrisi);
            this.Controls.Add(this.Unesi);
            this.Controls.Add(this.Tip);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TipAntikvitetaID);
            this.Controls.Add(this.label1);
            this.Name = "TipAntikviteta";
            this.Text = "TipAntikviteta";
            this.Load += new System.EventHandler(this.TipAntikviteta_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TipAntikvitetaID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Tip;
        private System.Windows.Forms.Button Unesi;
        private System.Windows.Forms.Button Obrisi;
        private System.Windows.Forms.Button Izmeni;
        private System.Windows.Forms.Button Izadji;
    }
}
﻿namespace B9
{
    partial class Antikviteti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.unosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipAntikvitetaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.periodiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lokalitetiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poArheologuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poTipuAntikvitetaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.krajToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.izlazAltIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unosToolStripMenuItem,
            this.lokalitetiToolStripMenuItem,
            this.krajToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(364, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // unosToolStripMenuItem
            // 
            this.unosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tipAntikvitetaToolStripMenuItem,
            this.periodiToolStripMenuItem});
            this.unosToolStripMenuItem.Name = "unosToolStripMenuItem";
            this.unosToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.unosToolStripMenuItem.Text = "Unos";
            // 
            // tipAntikvitetaToolStripMenuItem
            // 
            this.tipAntikvitetaToolStripMenuItem.Name = "tipAntikvitetaToolStripMenuItem";
            this.tipAntikvitetaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tipAntikvitetaToolStripMenuItem.Text = "Tip antikviteta";
            this.tipAntikvitetaToolStripMenuItem.Click += new System.EventHandler(this.tipAntikvitetaToolStripMenuItem_Click);
            // 
            // periodiToolStripMenuItem
            // 
            this.periodiToolStripMenuItem.Name = "periodiToolStripMenuItem";
            this.periodiToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.periodiToolStripMenuItem.Text = "Periodi";
            this.periodiToolStripMenuItem.Click += new System.EventHandler(this.periodiToolStripMenuItem_Click);
            // 
            // lokalitetiToolStripMenuItem
            // 
            this.lokalitetiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.poArheologuToolStripMenuItem,
            this.poTipuAntikvitetaToolStripMenuItem});
            this.lokalitetiToolStripMenuItem.Name = "lokalitetiToolStripMenuItem";
            this.lokalitetiToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.lokalitetiToolStripMenuItem.Text = "Lokaliteti";
            // 
            // poArheologuToolStripMenuItem
            // 
            this.poArheologuToolStripMenuItem.Name = "poArheologuToolStripMenuItem";
            this.poArheologuToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.poArheologuToolStripMenuItem.Text = "Po arheologu";
            this.poArheologuToolStripMenuItem.Click += new System.EventHandler(this.poArheologuToolStripMenuItem_Click);
            // 
            // poTipuAntikvitetaToolStripMenuItem
            // 
            this.poTipuAntikvitetaToolStripMenuItem.Name = "poTipuAntikvitetaToolStripMenuItem";
            this.poTipuAntikvitetaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.poTipuAntikvitetaToolStripMenuItem.Text = "Po tipu antikviteta";
            this.poTipuAntikvitetaToolStripMenuItem.Click += new System.EventHandler(this.poTipuAntikvitetaToolStripMenuItem_Click);
            // 
            // krajToolStripMenuItem
            // 
            this.krajToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.izlazAltIToolStripMenuItem});
            this.krajToolStripMenuItem.Name = "krajToolStripMenuItem";
            this.krajToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.krajToolStripMenuItem.Text = "Kraj";
            // 
            // izlazAltIToolStripMenuItem
            // 
            this.izlazAltIToolStripMenuItem.Name = "izlazAltIToolStripMenuItem";
            this.izlazAltIToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.izlazAltIToolStripMenuItem.Text = "Izlaz Alt+I";
            this.izlazAltIToolStripMenuItem.Click += new System.EventHandler(this.izlazAltIToolStripMenuItem_Click);
            // 
            // Antikviteti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Antikviteti";
            this.Text = "Antikviteti";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem unosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tipAntikvitetaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem periodiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lokalitetiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poArheologuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poTipuAntikvitetaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem krajToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem izlazAltIToolStripMenuItem;
    }
}


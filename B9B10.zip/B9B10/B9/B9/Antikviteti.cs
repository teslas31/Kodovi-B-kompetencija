﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B9
{
    public partial class Antikviteti : Form
    {
        public Antikviteti()
        {
            InitializeComponent();
        }

        private void tipAntikvitetaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TipAntikviteta ta = new TipAntikviteta();
            ta.Show();
        }

        private void poArheologuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PoArheologu pa = new PoArheologu();
            pa.Show();
        }

        private void izlazAltIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void periodiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Periodi per = new Periodi();
            per.Show();
        }

        private void poTipuAntikvitetaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PoAntikvitetu poan = new PoAntikvitetu();
            poan.Show();
        }
    }
}

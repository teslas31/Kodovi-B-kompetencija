﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B1B2konacno
{
    public partial class Pocetna : Form
    {
        public Pocetna()
        {
            InitializeComponent();
        }

        private void prijavaPasaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrijavaPasa f = new PrijavaPasa();f.Show();
        }

        private void spisakPasaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SpisakPasa f = new SpisakPasa();f.Show();

        }

        private void unosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Unos f = new Unos();f.Show();
        }

        private void spisakPasaPoRasiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SpisakPoRasi f = new SpisakPoRasi(); f.Show();
        }

        private void izlazToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

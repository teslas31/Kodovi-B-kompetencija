﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B33B34
{
    public partial class pocetna : Form
    {
        public pocetna()
        {
            InitializeComponent();
        }

        private void igraciToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Igraci f = new Igraci();
            f.Show();
        }

        private void spisakTerenaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SpisakIgraca f = new SpisakIgraca();
            f.Show();
        }

        private void spisakPartijaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SpisakPartija f = new SpisakPartija();
            f.Show();
        }

        private void tereniToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tereni f = new Tereni();
            f.Show();
        }
    }
}

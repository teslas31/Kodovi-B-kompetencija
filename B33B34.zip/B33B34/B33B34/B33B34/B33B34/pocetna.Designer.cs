﻿namespace B33B34
{
    partial class pocetna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.unosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.igraciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.unosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.igraciToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tereniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spiskoviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spisakTerenaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spisakPartijaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unosToolStripMenuItem,
            this.igraciToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(104, 48);
            // 
            // unosToolStripMenuItem
            // 
            this.unosToolStripMenuItem.Name = "unosToolStripMenuItem";
            this.unosToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.unosToolStripMenuItem.Text = "Unos";
            // 
            // igraciToolStripMenuItem
            // 
            this.igraciToolStripMenuItem.Name = "igraciToolStripMenuItem";
            this.igraciToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.igraciToolStripMenuItem.Text = "Igraci";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unosToolStripMenuItem1,
            this.spiskoviToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(538, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // unosToolStripMenuItem1
            // 
            this.unosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.igraciToolStripMenuItem1,
            this.tereniToolStripMenuItem});
            this.unosToolStripMenuItem1.Name = "unosToolStripMenuItem1";
            this.unosToolStripMenuItem1.Size = new System.Drawing.Size(46, 20);
            this.unosToolStripMenuItem1.Text = "Unos";
            // 
            // igraciToolStripMenuItem1
            // 
            this.igraciToolStripMenuItem1.Name = "igraciToolStripMenuItem1";
            this.igraciToolStripMenuItem1.Size = new System.Drawing.Size(105, 22);
            this.igraciToolStripMenuItem1.Text = "Igraci";
            this.igraciToolStripMenuItem1.Click += new System.EventHandler(this.igraciToolStripMenuItem1_Click);
            // 
            // tereniToolStripMenuItem
            // 
            this.tereniToolStripMenuItem.Name = "tereniToolStripMenuItem";
            this.tereniToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tereniToolStripMenuItem.Text = "Tereni";
            this.tereniToolStripMenuItem.Click += new System.EventHandler(this.tereniToolStripMenuItem_Click);
            // 
            // spiskoviToolStripMenuItem
            // 
            this.spiskoviToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.spisakTerenaToolStripMenuItem,
            this.spisakPartijaToolStripMenuItem});
            this.spiskoviToolStripMenuItem.Name = "spiskoviToolStripMenuItem";
            this.spiskoviToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.spiskoviToolStripMenuItem.Text = "Spiskovi";
            // 
            // spisakTerenaToolStripMenuItem
            // 
            this.spisakTerenaToolStripMenuItem.Name = "spisakTerenaToolStripMenuItem";
            this.spisakTerenaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.spisakTerenaToolStripMenuItem.Text = "Spisak terena";
            this.spisakTerenaToolStripMenuItem.Click += new System.EventHandler(this.spisakTerenaToolStripMenuItem_Click);
            // 
            // spisakPartijaToolStripMenuItem
            // 
            this.spisakPartijaToolStripMenuItem.Name = "spisakPartijaToolStripMenuItem";
            this.spisakPartijaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.spisakPartijaToolStripMenuItem.Text = "Spisak partija";
            this.spisakPartijaToolStripMenuItem.Click += new System.EventHandler(this.spisakPartijaToolStripMenuItem_Click);
            // 
            // pocetna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "pocetna";
            this.Text = "Golf klub";
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem unosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem igraciToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem unosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem igraciToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tereniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spiskoviToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spisakTerenaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spisakPartijaToolStripMenuItem;
    }
}


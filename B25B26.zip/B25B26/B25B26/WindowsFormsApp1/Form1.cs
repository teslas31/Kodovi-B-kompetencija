﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pROFESORIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Profesori f = new Profesori();
            f.Show();
        }

        private void pROFESORIKOJIIMAJUMEJLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            imajuMejl f = new imajuMejl();
            f.Show();
        }

        private void sTUDENTIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Studenti f = new Studenti();
            f.Show();
        }

        private void pROFESORIKOJINEMAJUMEJLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BezMejla f = new BezMejla();
            f.Show();
        }

        private void kRAJToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

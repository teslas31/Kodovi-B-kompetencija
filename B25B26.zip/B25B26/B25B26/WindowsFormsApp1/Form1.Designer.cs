﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.uNOSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pROFESORIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTUDENTIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kONSULTACIJEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pROFESORIKOJIIMAJUMEJLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pROFESORIKOJINEMAJUMEJLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iZLAZToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kRAJToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uNOSToolStripMenuItem,
            this.kONSULTACIJEToolStripMenuItem,
            this.iZLAZToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // uNOSToolStripMenuItem
            // 
            this.uNOSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pROFESORIToolStripMenuItem,
            this.sTUDENTIToolStripMenuItem});
            this.uNOSToolStripMenuItem.Name = "uNOSToolStripMenuItem";
            this.uNOSToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.uNOSToolStripMenuItem.Text = "UNOS";
            // 
            // pROFESORIToolStripMenuItem
            // 
            this.pROFESORIToolStripMenuItem.Name = "pROFESORIToolStripMenuItem";
            this.pROFESORIToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.pROFESORIToolStripMenuItem.Text = "PROFESORI";
            this.pROFESORIToolStripMenuItem.Click += new System.EventHandler(this.pROFESORIToolStripMenuItem_Click);
            // 
            // sTUDENTIToolStripMenuItem
            // 
            this.sTUDENTIToolStripMenuItem.Name = "sTUDENTIToolStripMenuItem";
            this.sTUDENTIToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.sTUDENTIToolStripMenuItem.Text = "STUDENTI";
            this.sTUDENTIToolStripMenuItem.Click += new System.EventHandler(this.sTUDENTIToolStripMenuItem_Click);
            // 
            // kONSULTACIJEToolStripMenuItem
            // 
            this.kONSULTACIJEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pROFESORIKOJIIMAJUMEJLToolStripMenuItem,
            this.pROFESORIKOJINEMAJUMEJLToolStripMenuItem});
            this.kONSULTACIJEToolStripMenuItem.Name = "kONSULTACIJEToolStripMenuItem";
            this.kONSULTACIJEToolStripMenuItem.Size = new System.Drawing.Size(96, 20);
            this.kONSULTACIJEToolStripMenuItem.Text = "KONSULTACIJE";
            // 
            // pROFESORIKOJIIMAJUMEJLToolStripMenuItem
            // 
            this.pROFESORIKOJIIMAJUMEJLToolStripMenuItem.Name = "pROFESORIKOJIIMAJUMEJLToolStripMenuItem";
            this.pROFESORIKOJIIMAJUMEJLToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.pROFESORIKOJIIMAJUMEJLToolStripMenuItem.Text = "PROFESORI KOJI IMAJU MEJL";
            this.pROFESORIKOJIIMAJUMEJLToolStripMenuItem.Click += new System.EventHandler(this.pROFESORIKOJIIMAJUMEJLToolStripMenuItem_Click);
            // 
            // pROFESORIKOJINEMAJUMEJLToolStripMenuItem
            // 
            this.pROFESORIKOJINEMAJUMEJLToolStripMenuItem.Name = "pROFESORIKOJINEMAJUMEJLToolStripMenuItem";
            this.pROFESORIKOJINEMAJUMEJLToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.pROFESORIKOJINEMAJUMEJLToolStripMenuItem.Text = "PROFESORI KOJI NEMAJU MEJL";
            this.pROFESORIKOJINEMAJUMEJLToolStripMenuItem.Click += new System.EventHandler(this.pROFESORIKOJINEMAJUMEJLToolStripMenuItem_Click);
            // 
            // iZLAZToolStripMenuItem
            // 
            this.iZLAZToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kRAJToolStripMenuItem});
            this.iZLAZToolStripMenuItem.Name = "iZLAZToolStripMenuItem";
            this.iZLAZToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.iZLAZToolStripMenuItem.Text = "IZLAZ";
            // 
            // kRAJToolStripMenuItem
            // 
            this.kRAJToolStripMenuItem.Name = "kRAJToolStripMenuItem";
            this.kRAJToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.I)));
            this.kRAJToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.kRAJToolStripMenuItem.Text = "KRAJ";
            this.kRAJToolStripMenuItem.Click += new System.EventHandler(this.kRAJToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "POCETNA";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem uNOSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pROFESORIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTUDENTIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kONSULTACIJEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pROFESORIKOJIIMAJUMEJLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pROFESORIKOJINEMAJUMEJLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iZLAZToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kRAJToolStripMenuItem;
    }
}

